### Setup

To clone the repository on your computer 
```bash
$ git clone https://github.com/kapilbarad/reactjs-login-form.git
$ cd reactjs-login-form.git
```

To install dependencies,
```bash
$ npm install
```

To run the project itself,
```bash
$ npm start
```